# Nether Config

This directory contains the work-in-progress Nether config pack for Terra.